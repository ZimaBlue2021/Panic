import UIKit

func numbers(numOne: Int, numTwo: Int ) -> Int {
var total = 0
total = numOne + numTwo

return total

}

var totalNumber = numbers(numOne: 4, numTwo: 4)
print(numbers(numOne: 4, numTwo: 4))











