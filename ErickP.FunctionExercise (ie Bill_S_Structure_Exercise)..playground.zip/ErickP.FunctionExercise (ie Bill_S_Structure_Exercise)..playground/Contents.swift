import UIKit

struct carEngine {
var v4engine = " a v4 engine has a four cylinder piston engine"
var v6engine = " a v6 engine has six cylinder piston engine"
var v8engine = " a v8 engine has eight cylinder piston engine"
}
let myCarEngine = carEngine()
print("The differnce of each engine is \(carEngine()) I would recommended the v4 because it uses less fuel but if your a speed lover get the v8.")








