import UIKit

var one = 1
var two = 2
let three = 3
let four = 4
let five = 5
let six = 6
let seven = 7
let eight = 8
let nine = 9
let ten = 10

var add = one + two
print(add)
var subtract = three - four
print(subtract)
var multiply = two * six
print(multiply)
var divide = ten / five
print(divide)


var addition = add + nine
print(addition)
var subtraction = subtract - five
print(subtraction)
var multiplication = multiply * four
print(multiplication)
var division = divide / one
print(division)




