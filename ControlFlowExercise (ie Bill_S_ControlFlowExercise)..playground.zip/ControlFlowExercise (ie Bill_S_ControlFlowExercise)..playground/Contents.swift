import UIKit

var itemscollected: [String] = ["bass guitar", "xbox"]

itemscollected.append ("switch")

itemscollected += ["electric guitar", "acoustic guitar"]

print("my aray has \(itemscollected.count) items")

var firstitem = itemscollected[0]

for item in itemscollected {

print(item)
}
















