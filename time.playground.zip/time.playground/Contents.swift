import UIKit

var Time = 180


for index in 1...180 {
print(" seconds \(index)")
}

if Time <= 180 {
print(" wait ")
}
if Time == 180 {
print(" Ready ")
}





















